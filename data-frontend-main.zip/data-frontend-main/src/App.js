import './App.css';
import Interface from './main/Interface';

function App() {
  return (
    <div className="App">
      <Interface/>
    </div>
  );
}
export default App;